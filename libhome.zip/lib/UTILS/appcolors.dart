 import 'dart:ui';

class AppColors{
  static final primarycolor=Color(0xffcdfb47);
  static final secondaryolor=Color(0xffAE0019);
  static final teritarycolor=Color(0xfaAa0001);


 }


